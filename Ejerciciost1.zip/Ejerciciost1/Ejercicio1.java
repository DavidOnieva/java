public class Ejercicio1 {
    public static void main(String[] args) {
        System.out.println("David Onieva");
    }
}